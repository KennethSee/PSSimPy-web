from PSSimPy.transaction import Transaction

from PSSimPy.constraint_handler import AbstractConstraintHandler

class CustomConstraintHandler(AbstractConstraintHandler):


    def __init__(self):
        AbstractConstraintHandler.__init__(self)

    

    def process_transaction(self, transaction: Transaction):        
        self.passed_transactions.append(transaction)


    def get_passed_transactions(self):
        """Returns the list of passed transactions."""
        return self.passed_transactions
    
    def clear(self):
        self.passed_transactions = []
