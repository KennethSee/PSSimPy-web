from typing import List, Dict

from PSSimPy.credit_facilities import AbstractCreditFacility

from PSSimPy import Account

class CustomCreditFacility(AbstractCreditFacility):
    

    def __init__(self):
        AbstractCreditFacility.__init__(self)

        
    def collect_all_repayment(self, day: int, accounts: List[Account]) -> None:
        """
        Collect all repayment of a list of accounts.

        :param accounts: List of participants' account
        """
        for account in accounts:
            self.history[account.id].append((day, self.get_total_credit(account), self.get_total_fee(account)))
            self.collect_repayment(account=account)
            

    def calculate_fee(self, amount: float) -> float:
        return 0.0

        

    def lend_credit(self, account: Account, amount: float) -> float:
        if amount > account.posted_collateral: return 0.0
        self.used_credit[account.id].append(amount)
        account.balance += amount
        account.posted_collateral -= amount

    

    def collect_repayment(self, account: Account) -> None:
        # repay credit facility if possible
        for i, amount in enumerate(self.used_credit[account.id]):
            if amount <= account.balance:
                account.balance -= amount
                account.posted_collateral += amount
                self.used_credit[account.id][i] = 0

        # remove repaid credit facility
        self.used_credit[account.id] = [cr for cr in self.used_credit[account.id] if cr != 0]


    def get_total_credit(self, account: Account) -> float:
        """
        Obtain the total amount of credit lent to a participant.
               
        :param account: Participant's account
        :return: The total amount of credit
        """
        return sum(self.used_credit[account.id])

    def get_total_fee(self, account: Account) -> float:
        """
        Obtain the total fee amount for a participant.
        
        :param account: Participant's account
        :return: The total fee amount
        """
        return sum([self.calculate_fee(x) for x in self.used_credit[account.id]])
    
    def get_total_credit_and_fee(self, account: Account) -> float:
        """
        Obtain the total amount of credit and fee for a participant.

        :param account: Participant's account
        :return: The total amount of credit and fee
        """
        return self.get_total_credit(account) + self.get_total_fee(account)
