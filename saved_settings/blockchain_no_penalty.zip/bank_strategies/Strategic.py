from PSSimPy.queues import AbstractQueue

class Strategic:


    def __init__(self, name, strategy_type='Strategic', **kwargs):
        self.name = name
        self.strategy_type = strategy_type
        for key, value in kwargs.items():
            setattr(self, key, value)


    # only relevant for agent-based modeling

    def strategy(self, txns_to_settle: set, all_outstanding_transactions: set, sim_name: str, day: int, current_time: str, queue: AbstractQueue) -> set:
        final_txn_list = set()
        # for each txn to settle, calculate expected cost of delay and expected cost of timely settlement
        for txn in txns_to_settle:
            txn_amount = txn.amount
            hypo_balance = txn.sender_account.balance

            exp_cost_of_delay = txn_amount * 0.0 # assume no penalty
            positive_balance_after_pmt = True if hypo_balance - txn_amount >= 0 else False
            exp_cost_of_timely_pmt = 0 if positive_balance_after_pmt else txn_amount * 0.15 # assume oppurtunity cost is 15%

            # only settle if the expected cost of delay is more than expected cost of timely settlement
            if exp_cost_of_delay >= exp_cost_of_timely_pmt:
                final_txn_list.add(txn)
        return final_txn_list

