from typing import Tuple

from PSSimPy.queues import AbstractQueue

from PSSimPy import Transaction

from PSSimPy.utils import min_balance_maintained

class CustomQueue(AbstractQueue):


    def __init__(self):
        AbstractQueue.__init__(self)


    def next_period(self):
        self.period_counter += 1

    def reset_period(self):
        self.period_counter = 0


    @staticmethod
    def sorting_logic(queue_item: Tuple[Transaction, int]) -> int:
        _, period = queue_item
        return period



    @staticmethod
    def dequeue_criteria(queue_item: Tuple[Transaction, int]) -> bool:
        txn = queue_item[0]
        if txn.sender_account.balance - txn.amount >= 0:
            print(f'Sender {txn.sender_account.id}')
            print(txn.sender_account.balance - txn.amount)
            return True
        else:
            return False

    
    def enqueue(self, transaction: Transaction) -> None:
        self.queue.add((transaction, self.period_counter))

    def bulk_enqueue(self, transactions: Set[Transaction]) -> None:
        for transaction in transactions:
            self.enqueue(transaction)
    
    def dequeue(self, queue_item: Tuple[Transaction, int]) -> Transaction:
        self.queue.remove(queue_item)

    def begin_dequeueing(self) -> List[Transaction]:
        items_to_dequeue = []
        for item in self.queue:
            if self.dequeue_criteria(item):
                items_to_dequeue.append(item)
        for item in items_to_dequeue:
            self.dequeue(item)
        return [transaction for transaction, _ in items_to_dequeue]
    
    def get_num_txns(self) -> int:
        return len(self.queue)

    def get_txn_amount_total(self) -> float:
        total_amount = sum([transaction.amount for transaction, _ in self.queue])
        return total_amount
