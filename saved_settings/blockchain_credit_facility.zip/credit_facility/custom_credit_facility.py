from typing import List, Dict

from PSSimPy.credit_facilities import AbstractCreditFacility

from PSSimPy import Account

class CustomCreditFacility(AbstractCreditFacility):
    

    def __init__(self, collateralized_transactions={}):
        AbstractCreditFacility.__init__(self)
        self.collateralized_transactions = collateralized_transactions

        
    def collect_all_repayment(self, day: int, accounts: List[Account]) -> None:
        """
        Collect all repayment of a list of accounts.

        :param accounts: List of participants' account
        """
        for account in accounts:
            self.history[account.id].append((day, self.get_total_credit(account), self.get_total_fee(account)))
            self.collect_repayment(account=account)
            

    def calculate_fee(self, credit_amount) -> float:
        return 0.0

        

    def lend_credit(self, account, amount: float) -> None:
        # if amount > account.posted_collateral:
        # check if there are incoming transactions that can be used as collateral
        # use the incoming transaction with the lowest value that exceeds the amount being requested
        lowest_valid_amt = float('inf')
        lowest_valid_amt_txn = None
        for transaction in {txn for txn in account.txn_in if txn.status_code == 0 and txn not in self.collateralized_transactions.get(account.id, set())}:
            if transaction.amount >= amount and transaction.amount < lowest_valid_amt:
                lowest_valid_amt = transaction.amount
                lowest_valid_amt_txn = transaction
        if lowest_valid_amt_txn is not None:
            self.collateralized_transactions.setdefault(account.id, set()).add(lowest_valid_amt_txn)
            # self.used_credit[account.id].append(amount)
            account.balance += amount
            # account.posted_collateral -= amount
        else:
            # use normal collateral process
            if amount > account.posted_collateral: return 0.0
            self.used_credit[account.id].append(amount)
            account.balance += amount
            account.posted_collateral -= amount

    

    def collect_repayment(self, account: Account) -> None:
        # First, attempt to repay credit from collateralized transactions if they exist
        if account.id in self.collateralized_transactions:
            for transaction in list(self.collateralized_transactions[account.id]):
                if transaction.amount <= account.balance:
                    account.balance -= transaction.amount
                    account.posted_collateral += transaction.amount
                    # Remove transaction from collateralized_transactions after repayment
                    self.collateralized_transactions[account.id].remove(transaction)

            # Clean up collateralized_transactions if empty
            if not self.collateralized_transactions[account.id]:
                del self.collateralized_transactions[account.id]

        # Next, attempt to repay credit from used_credit if it exists
        if account.id in self.used_credit:
            for i, amount in enumerate(self.used_credit[account.id]):
                if amount <= account.balance:
                    account.balance -= amount
                    account.posted_collateral += amount
                    self.used_credit[account.id][i] = 0

            # Remove any zeroed out credits from used_credit
            self.used_credit[account.id] = [cr for cr in self.used_credit[account.id] if cr != 0]

            # Clean up used_credit if empty
            if not self.used_credit[account.id]:
                del self.used_credit[account.id]


    def get_total_credit(self, account: Account) -> float:
        """
        Obtain the total amount of credit lent to a participant.
               
        :param account: Participant's account
        :return: The total amount of credit
        """
        return sum(self.used_credit[account.id])

    def get_total_fee(self, account: Account) -> float:
        """
        Obtain the total fee amount for a participant.
        
        :param account: Participant's account
        :return: The total fee amount
        """
        return sum([self.calculate_fee(x) for x in self.used_credit[account.id]])
    
    def get_total_credit_and_fee(self, account: Account) -> float:
        """
        Obtain the total amount of credit and fee for a participant.

        :param account: Participant's account
        :return: The total amount of credit and fee
        """
        return self.get_total_credit(account) + self.get_total_fee(account)
